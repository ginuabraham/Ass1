const fs=require('fs');

fs.readFile('input.txt','utf-8',function(err,data)
{
	if(err){
		console.write("Problem in reading File");
	}else{
		console.log(data);
	}
});
console.log("End");


