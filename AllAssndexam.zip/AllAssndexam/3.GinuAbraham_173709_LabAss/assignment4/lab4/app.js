    //==============================================declarations======================
var express = require('express')
const path=require('path')

var app= new express()

const route=require('./router/router')
app.set('views',path.join(__dirname,"views"))
app.set("view engine","pug")
const bodyParser=require('body-parser')

//================================================================ funcs()==================
app.use(express.json())
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.get('/',(req,res)=>{
    res.send('hello from root path')
})
app.use('/api',route)


//create server

const port=3000
app.listen(port,function(){
    console.log('server running in 3000 port')
})