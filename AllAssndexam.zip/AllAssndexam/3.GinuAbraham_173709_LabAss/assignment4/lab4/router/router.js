var express = require('express')

var router=express.Router();
var shows=require('../model/show')
const fileObj = require('fs')
router.get('/',(req,res)=>{
    console.log('for mobiles list go to localhost://2000/api/mobiles')
})


//==========================================================get
router.get("/shows",(req,res,next)=>{

    fileObj.readFile('show.json', function (error, show) {
        if (error) {
            console.log(error)
        }
        else{
            let show1=JSON.parse(show)

        res.render('index',{
            showsList:show1.shows
        })
        }
    })
})

//==========================================================
router.get("/booknow/:showName",(req,res,next)=>{
   
    fileObj.readFile('show.json', function (error, data) {
        if (error) {
            
            console.log(error)
        }
        else{
            
            let showlist=JSON.parse(data)
            for( shw of showlist.shows){

                if(shw.showName==req.params.showName){
                    res.render('booknow',{
                        shw
                    })
                    break;
                }
            }
           
        }
    })

});
//======================================================================confirm book
router.post("/bookConfirm",(req,res,next)=>{
   let conShow={}
   conShow=req.body
    fileObj.readFile('show.json', function (error, data) {
        if (error) {
            console.log(conShow)

            console.log(error)
        }
        else{
            
            let showlist=JSON.parse(data)
            for( let shw=0;shw< showlist.shows.length;shw++){
        
                if(showlist.shows[shw].showName==req.body.showName){
                    showlist.shows[shw].availableSeats-=conShow.bookSeatCount
                    fileObj.writeFile('show.json',JSON.stringify(showlist),function (error, data) {})
                    res.render('success',{
                        show:conShow,
                        price:conShow.price*conShow.bookSeatCount

                    })
                    break;
                }
            }
           
        }
    })

});



module.exports=router;