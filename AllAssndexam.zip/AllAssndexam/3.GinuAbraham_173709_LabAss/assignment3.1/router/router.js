var express = require('express')
const fileObj=require('fs')

var router=express.Router();
var emps=require('../model/employee')
router.get('/',(req,res)=>{
    console.log('am from router module')
})
//=====================================================add

router.post("/emp",(req,res,next)=>{
    const ipEmp= {
        empId: req.body.empId,
        empName: req.body.empName,
        empSalary: req.body.empSalary,
        empAddress:req.body.empAddress
    };
    console.log(ipEmp)
 fileObj.readFile('employee.json', function (error, data) {
        if (error) {

            console.log(error)
        }
        else{
            
            let empList=JSON.parse(data)
            // empList[empList.length]=ipEmp
            empList.employee.push(ipEmp)
 fileObj.writeFile('employee.json',JSON.stringify(empList),function(error,data){
        if(error){
            console.log("Problem in writing")
        }
        else
        console.log("data written into file")
    
    })
        }
    })
   
});

//==========================================================get
router.get("/emps",(req,res,next)=>{

    fileObj.readFile('employee.json', function (error, data) {
        if (error) {

            console.log(error)
        }
        else{
            
            let empList=JSON.parse(data)

            
           res.send(empList)
           console.log(empList)
        }
    })

});

//=======================================================================getBy State

router.get("/emp/:state",(req,res,next)=>{

    fileObj.readFile('employee.json', function (error, data) {
        if (error) {

            console.log(error)
        }
        else{
            let empList=JSON.parse(data)
            let emparray=[]
            for( let emp of empList.employee){
        
                if(emp.empAddress.state==req.params.state){
                 emparray.push(emp)
                }
            }
            res.send(emparray)
                 console.log(emparray)
           
        }
    })

});

//======================================================================Update city 
router.put("/emp",(req,res,next)=>{
       fileObj.readFile('employee.json', function (error, data) {
        if (error) {
            console.log(error)
        }
        else{

            
            let empList=JSON.parse(data)
            for( let emp=0;emp< empList.employee.length;emp++){
        
                if(empList.employee[emp].empId==req.body.empId){

                    empList.employee[emp].empAddress.city=req.body.empAddress.city
                    res.send(empList)

                    fileObj.writeFile('employee.json',JSON.stringify(empList),function (error, data) {})
            
                }
            }
           
        }
    })

})
module.exports=router;