const fs=require('fs');

fs.readFile('input.txt','utf-8',function(err,data)
{
	if(err){
		console.write("Problem in reading File");
	}else{
		fs.writeFile('output.txt',data,function(err)
		{
			if (err)
				return console.log(err);
        });
        console.log(data);
		}
});
console.log("End");


