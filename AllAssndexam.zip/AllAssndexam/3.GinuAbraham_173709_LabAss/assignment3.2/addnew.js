var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/emp';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established", url);
        var db = client.db('emp');
        var collection = db.collection('emps');
        //adding new mobiledata
     

        collection.insert([{"empId": 1006,
        "empName": "Anusha",
        "empSalary": 40000,
        "empAddress": {
          "city": "shimoga",
          "state": "Karnataka"}

        }], function (err, data) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of ', data);
            }
        });
    }
});