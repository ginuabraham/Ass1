import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/model/User';
import { Router } from '@angular/router';
import { TasksService } from 'src/app/services/tasks.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  tasks: Task[];
  constructor(private userservice: TasksService,
    private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      this.userservice.gettasks().subscribe(data => {
        this.tasks = data;
      });
    }
    else {
      this.router.navigate(['login']);
    }
  }

  //delete
  deleteTask(task: Task): void {
    let result = confirm("Do you want to delete ?")
    if (result) {
      this.userservice.deleteTask(task.id).subscribe(data => {
        this.tasks = this.tasks.filter(t => t !== task);
      })
    }
  }

  //Adding Task
  addTask(): void {
    this.router.navigate(['add']);
  }

  //edit user
  editTask(task: Task): void {
    localStorage.removeItem("editTaskId");
    localStorage.setItem("editTaskId", task.id.toString());
    this.router.navigate(['edit']);
  }
}
