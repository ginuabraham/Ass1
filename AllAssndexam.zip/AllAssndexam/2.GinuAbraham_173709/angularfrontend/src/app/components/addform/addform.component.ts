import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TasksService } from 'src/app/services/tasks.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addform',
  templateUrl: './addform.component.html',
  styleUrls: ['./addform.component.css']
})
export class AddformComponent implements OnInit {

  addForm: FormGroup;
  submitted:boolean=false;
  constructor(private formbuilder:FormBuilder,
    private router:Router, private taskservice:TasksService) { }

  ngOnInit() {
    this.addForm= this.formbuilder.group({
      id:[],
     name:['',Validators.required],
      status:['',Validators.required]
    
    });
  }
  onSubmit()
  {
    this.submitted = true;
    if(this.addForm.invalid)
    {
      return;
    }
    this.taskservice.createTask(this.addForm.value)
    .subscribe(data =>{ 
      alert('record added..!!');
    });
    this.router.navigate(['todo']);
  }
}
