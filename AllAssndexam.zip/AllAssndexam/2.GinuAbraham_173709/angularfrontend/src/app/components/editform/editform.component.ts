import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { TasksService } from 'src/app/services/tasks.service';
import { Router } from '@angular/router';
import { Task } from 'src/app/model/User';

@Component({
  selector: 'app-editform',
  templateUrl: './editform.component.html',
  styleUrls: ['./editform.component.css']
})
export class EditformComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  task: Task;

  constructor(private formbuilder: FormBuilder,
    private router: Router, private taskservice: TasksService) { }


  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      let taskId = localStorage.getItem("editTaskId");
      if (!taskId) {
        alert('Invalid Action');
        this.router.navigate(['todo']);
        return;
      }

      this.editForm = this.formbuilder.group({
        id: [],
        name: ['', Validators.required],
        status: ['', Validators.required]
      });
      this.taskservice.getTasksById(+ taskId).subscribe(data => { this.editForm.setValue(data) });
    }
    else {
      this.router.navigate(['/login']);
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }
    this.taskservice.editTask(this.editForm.value)
      .subscribe(data => {
        alert('record added..!!');
      });
    this.router.navigate(['todo']);
  }

}
