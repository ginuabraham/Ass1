import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Parent from './components/Parent'
class App extends Component {
  render() {
    return (
      <div>
      <Parent>
          <br/>
          <button>register</button>
          <br/>
          <h1>This is sample content</h1>
        </Parent>
      </div>
    );
  }
}

export default App;
