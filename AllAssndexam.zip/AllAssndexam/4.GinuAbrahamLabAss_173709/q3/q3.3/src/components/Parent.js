import React from 'react';




import ReactDOM from 'react-dom';







class Parent extends React.Component {

    render() {
        let length
        let elementLength=[]

        const childArr = ['asdb', 'b', 'c', 'dhfghtfgh', 'f', 'jsasdqasasasasas'];
        length=childArr.length

        React.Children.forEach(childArr,

            child => (
                elementLength.push(child.length)

            ));





        return (

            <div>

                {this.props.children}
                <p>Number of elements in array: {length}</p>
               

               
                {childArr.map((child, index) => ( <div>
                    <h3>{"Index: "+index}{"    value: "+child}{'    length: '+elementLength[index]}</h3>
                   
                    </div>
                    ))}

           

            </div>
        )
       


    }
 
}

export default Parent;
