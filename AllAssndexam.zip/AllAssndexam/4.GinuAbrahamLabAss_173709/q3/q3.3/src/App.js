import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Parent from './components/Parent'

class App extends Component {
  render() {
    return (
      <Parent>

<h1>i am child</h1>

<h1>i am child</h1>

</Parent>
    );
  }
}

export default App;
