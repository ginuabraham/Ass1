import React, { Component } from 'react';
import './App.css';
import Movie from './components/movielist';

class App extends Component {
 
    state={
      movie:[
        { movieLink:"./harrypotter.jfif", ticketp: " 100 " , moviename: " HarryPotter "},
        { movieLink: "./avengers.jfif",ticketp: " 200 " , moviename: " Avangers "}
      ]
      }  
   render() {  
    return (
      <div >
        console.log(this.state.movie);
        
      <Movie movie={this.state.movie} />
      </div>
    );
  }
}

export default App;
