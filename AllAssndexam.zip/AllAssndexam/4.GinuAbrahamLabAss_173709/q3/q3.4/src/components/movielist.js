import React, { Component } from 'react'
export class Movie extends Component {

    render() {
        return (
            <div>
                <h1> Movie </h1>

                <table class="table table-bordered">
               
                    <tbody>

                        {this.props.movie.map((n) =>
                           
                                <tr>
                                    <td>
                                        <img src={require(`${n.movieLink}`)}/>
                                       <h1> {n.moviename}</h1>
                                       <h1> {n.ticketp}</h1>
                                    </td> 
                                </tr>
                        )}    
                    </tbody>
                </table>

            </div>
        )
    }
}
export default Movie