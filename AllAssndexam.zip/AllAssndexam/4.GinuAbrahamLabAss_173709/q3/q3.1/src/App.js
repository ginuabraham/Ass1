import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import RenderQ from './components/render';

class App extends Component {
  render() {
    return (
      <div >
        < RenderQ/>
      </div>
    );
  }
}

export default App;
