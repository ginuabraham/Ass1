import React from 'react'; 
import ReactDOM from 'react-dom'; 

export class RenderQ extends React.Component {
    render() {
        return (
            <div>
            <h1>Welcome to Capgemini</h1> 
               
            </div>
        )
    }
}
ReactDOM.render(<RenderQ/>,document.getElementById("root") )

export default RenderQ;  
