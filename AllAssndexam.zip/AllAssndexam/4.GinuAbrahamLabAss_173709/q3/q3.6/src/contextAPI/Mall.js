import React from 'react'
import Theatre from './Theatre';

class Mall extends React.Component{
    render(){
        return(
            <div>
                <h1>Mall</h1>
                <Theatre />
            </div>
        )
    }
}
export default Mall ;