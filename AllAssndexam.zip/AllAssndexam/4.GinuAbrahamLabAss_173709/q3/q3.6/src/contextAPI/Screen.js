import React from 'react'
import {MallContext} from './Index'
const MovieDisplay=(props)=>{
    return(
        <div>
            <h2>{props.movies.map((n)=>
            <h2>{n.name}</h2>)}</h2>

            <h1>Screen Name</h1>
            {props.movies.map((n)=>
            <li>{n.movie}</li>)}

            <h2>Screen Time</h2>
            {props.movies.map((n)=>
            <li>{n.time}</li>)}

        </div>
    )
}
class Screen extends React.Component{
    render() {
        return (
            <MallContext.Consumer>
                {(movies) => <MovieDisplay movies={movies}>
                </MovieDisplay>
            }
            </MallContext.Consumer>
        )
    }
}
export default Screen;