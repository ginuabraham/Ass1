import React from 'react'
import Screen from './Screen';

class Theatre extends React.Component{
    render(){
        return(
            <div>
                <h1>Theatre </h1>
            <Screen/>
            </div>
        )
    }
}
export default Theatre ;