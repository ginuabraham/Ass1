import React, { Component } from 'react';
import './App.css';
import ContextDemo from './contextAPI/Index';

class App extends Component {
  render() {
    return (
      <div className="App">
      
       <ContextDemo/>
      </div>
    );
  }
}

export default App;
