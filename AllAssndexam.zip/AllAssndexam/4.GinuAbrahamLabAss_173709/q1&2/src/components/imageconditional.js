import React, { Component } from 'react'
export class ImageConditional extends Component {
    constructor(){
        super()
        this.state={display:false}
    }
    onChange=()=>{
        this.setState({display:!this.state.display})
    }
    render() {
        return (
            <div>
                <h1>Image Conditional</h1>
                <button onClick={this.onChange}>Change image</button>
                {
                    this.state.display ?
                    <img src={require('./black.png')}/>:<img src={require('./white.png')}/>
                }
            </div>
        )
    }
}

export default ImageConditional;