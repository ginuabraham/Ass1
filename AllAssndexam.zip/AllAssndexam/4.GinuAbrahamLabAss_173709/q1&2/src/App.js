import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ImageConditional from './components/imageconditional'

class App extends Component {
  render() {
    return (
      <div>
       <ImageConditional/>
      </div>
    );
  }
}

export default App;
