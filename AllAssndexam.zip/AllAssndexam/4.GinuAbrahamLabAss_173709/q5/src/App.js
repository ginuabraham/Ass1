import React, { Component } from 'react';
import './App.css';
import Clock from './Clock';

  class App extends Component {
    
    constructor() {
      super();
      this.launchClock()
      this.state = {currentTime: (new Date()).toLocaleString(),
        toggle1:false
              }
      console.log(this.state)
    }
    launchClock() {
      setInterval(()=>{
        this.setState({
          currentTime: (new Date()).toLocaleString(),
          toggle1:!this.state.toggle1  
        })
      }, 1000)

    }
   
    render() {
      return (
        <div>
          {
            this.state.toggle1?<Clock/>:<h1>Capgemini</h1>
          }
          
        {this.state.currentTime}</div>
      );
    }
  }

export default App;
