import { createStore } from "redux";
import todoReducer from './reducers/todoreducers'
const AppWithstore = createStore(todoReducer);
export default AppWithstore;
