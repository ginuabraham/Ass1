export function addTodo(todo) {
    return {
        type: 'ADD_TODO',
        data: todo
    }
}

export function fetchTodos() {
    return {
        type: 'FETCH_TODO'
    }
}

