import React, { Component } from 'react';

import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import Category1 from './category1';
import Category2 from './category2';
import Category3 from './category3';

const AppNavigation = (props) => {
    return (
        <Router>

            <ul>
                <Link to="/samsung">Samsung</Link><br/>
                <Link to="/mi">Mi</Link><br/>
                <Link to="/nokia">Nokia</Link>
            </ul>
            <Route exact path='/samsung' component={Category1}></Route>
            <Route extact path='/mi' component={Category2}></Route>
            <Route extact path='/nokia' component={Category3}></Route>
        </Router>
    );
}

export default AppNavigation;
