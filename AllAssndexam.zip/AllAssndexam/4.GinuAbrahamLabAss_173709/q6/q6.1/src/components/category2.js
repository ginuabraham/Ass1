import React, { Component } from 'react'
export class Category2 extends Component {
    render() {
        return (
            <div>
                <img src={require ('./mi.jpg')}/> 
        <h1>Description</h1>
        <p>
          4000mAh two-day battery, Full Screen Display, Qualcomm® Snapdragon™
          636. Xiaomi's first smartphone with AI Powered Quad camera. Buy Now!
          Vast Service Network. Cash on delivery. EMI Option. Hassle-Free
          Replacement. Mi Protect Warranty.
        </p>
             
            </div>
        )
    }
}

export default Category2;

