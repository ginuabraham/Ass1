import React, { Component } from 'react'
import { BrowserRouter as Router, Link, Route } from 'react-router-dom';
import Login from './login';
export class SignOut extends Component {


    logoutHandler = (e) => {
        this.props.history.push('/login')
    }
    render() {
        const user = this.props.userData;
        return (
            <div>
                <h3>Welcome {user.userName}</h3>
                <Router>

                    <button onClick={() => this.props.signOut()}>

                        <Link to="./login">Signout</Link>

                        <Route exact path="./login" component={Login}/>

                    </button>

                </Router>

            </div>
        )
    }
}

export default SignOut
