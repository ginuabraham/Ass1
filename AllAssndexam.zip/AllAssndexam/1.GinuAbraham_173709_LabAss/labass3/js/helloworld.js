var msg;
msg="<b>Hello World </b>";