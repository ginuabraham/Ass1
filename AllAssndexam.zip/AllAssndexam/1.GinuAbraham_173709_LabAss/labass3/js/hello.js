function dispHello(){
    document.write("this text is displayed by calling an external function: <b> Hello World </b>");
}