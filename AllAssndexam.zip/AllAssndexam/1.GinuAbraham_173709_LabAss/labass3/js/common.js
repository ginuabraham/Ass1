var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(headVar,bodyVar) {
document.write(msg+"<br/>");
var result= headVar+bodyVar;
document.write("The sume of the variable of headvar and bodyvar is: "+ result);
} 