import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Assgin1Component } from './assgin1.component';

describe('Assgin1Component', () => {
  let component: Assgin1Component;
  let fixture: ComponentFixture<Assgin1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Assgin1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Assgin1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
