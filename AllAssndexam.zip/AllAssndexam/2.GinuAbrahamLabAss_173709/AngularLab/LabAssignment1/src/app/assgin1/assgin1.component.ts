import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assgin1',
  templateUrl: './assgin1.component.html',
  styleUrls: ['./assgin1.component.css']
})
export class Assgin1Component implements OnInit {

  constructor() { }
  id: number;
  name: string;
  salary: number;
  department: string;

addEmp(){
  console.log(this.id +" "+this.name +" "+this.salary +" "+this.department);
  alert(this.id+ " "+this.name+" "+this.salary+ " "+this.department);
}
ngOnInit() {}
}
