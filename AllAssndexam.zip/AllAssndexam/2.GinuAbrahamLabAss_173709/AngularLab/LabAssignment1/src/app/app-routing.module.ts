import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { Assgin1Component } from './assgin1/assgin1.component';
import { Assign2Component } from './assign2/assign2.component';
import { Assign3Component } from './assign3/assign3.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'ass1',component:Assgin1Component},
  {path:'ass2',component:Assign2Component},
  {path:'ass3',component:Assign3Component}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
