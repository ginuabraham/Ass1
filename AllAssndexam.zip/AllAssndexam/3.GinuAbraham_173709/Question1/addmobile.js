var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/mobile';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        //Creating database
        var db = client.db('mobile');

        //creating collection
        var collection = db.collection('mobilescol');


        //find all mobiles details
        collection.insert([{
            "mobId": 1006,
            "mobName": "RedmiNotePro",
            "mobPrice": 6661.1
        }], function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('data is  ', res);
            }
        });
    }
});