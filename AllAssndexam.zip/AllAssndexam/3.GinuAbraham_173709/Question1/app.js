var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/mobile';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        //Creating database
        var db = client.db('mobile');

        //creating collection
        var collection = db.collection('mobilescol');

        var mobiles = [
            {
                "mobId": 1001,
                "mobName": "iPhone",
                "mobPrice": 76661.1
            },
            {
                "mobId": 1002,
                "mobName": "MicroMax",
                "mobPrice": 126661.1
            },
            {
                "mobId": 1003,
                "mobName": "Coolpad",
                "mobPrice": 7823
            },
            {
                "mobId": 1004,
                "mobName": "HTC",
                "mobPrice": 8876
            },
            {
                "mobId": 1005,
                "mobName": "LG",
                "mobPrice": 46661.1
            }
        ]

        //inserting data
        collection.insert(mobiles, function (err, data) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of ', data);
            }
        });
        
    }
});