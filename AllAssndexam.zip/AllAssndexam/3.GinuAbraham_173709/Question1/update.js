var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/mobile';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err)
    }
    else {
        console.log('connection established' + url);

        //creating database
        var db = client.db('mobile');

        //creating collection
        var collection = db.collection('mobilescol');

        collection.update({ 'mobId': 1002 }, { $set: { 'mobName': 'Redmi' } }, function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('Updated Data' + res);
            }

        });
    }
});