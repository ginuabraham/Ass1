var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/test';

//connecting to mongo
mongoclient1.connect(url, function(err, client)
{
    if(err)
    {
        console.log(err)
    }
    else
    {
        console.log('connection established'+url);
        var db = client.db('test');
        var collection = db.collection('cust');
        var custone = {custid: 100, custname:'Rahul'};
        collection.insert([custone], function(err,data)
        {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log('number of rows inserted' +data);
            }
          
        });
    }
});