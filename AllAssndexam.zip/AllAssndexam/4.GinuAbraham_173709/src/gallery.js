import React, { Component } from 'react'

export class Gallery extends Component {
  render() {
    return (
      <div>
        <h2>Gallery</h2>
 <img src={require('./gal1.jpg') }/> 
 <img src={require('./gal2.jpg') }/> 
 <img src={require('./gal3.jpg') }/> 
      </div>
    )
  }
}
export default Gallery
