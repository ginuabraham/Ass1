import React from 'react'
import './App.css';
import axios from 'axios';
import ShowContact from './showcontact';
export class ViewComp extends React.Component {
    constructor() {
        super()
        this.state = { contacts: [] }

    }
    baseurl = "  http://localhost:3000/contacts";
    getContacts = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ contacts: response.data })
        });
    }
    componentDidMount() {
        this.getContacts();
    }
    render() {
        return (
            <div>
                <ShowContact contacts={this.state.contacts}  />
            </div>
        )
    }
}
export default ViewComp;