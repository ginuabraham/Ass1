import React, { Component } from 'react'

export class About extends Component {
  render() {
    return (
      <div>
          <h1>About Us..</h1>
          <p>Contacts App (Android) is an address book replacement that helps organize
            your contacts and integrates with your social media accounts and communications.
            The app automatically imports information from linked social networks such as
             Facebook,Google+, Twitter and LinkedIn contacts.
             </p>
          
      </div>
    )
  }
}

export default About
