import React from 'react'
import AddContact from './addcontact';
import ShowContact from './showcontact';
import axios from 'axios';

export class ViewContact extends React.Component {
    constructor() {
        super()
        this.state = { contacts: [] }

    }

    baseurl = "  http://localhost:3000/contacts";
    getContacts = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ contacts: response.data })
        });
    }
    addContact = (contact) => {
        axios.post(this.baseurl, contact).then((response) => {
            this.getContacts();
            alert("contact added")
        })
    }
   
    componentDidMount() {
        this.getContacts();
    }
    render() {
        return (
            <div>
                <h1> Manage Contact</h1>
                <AddContact addContact={(contact) => this.addContact(contact)} />
                <ShowContact contacts={this.state.contacts}  />
            </div>

        )
    }
}
export default ViewContact;