import React, { Component } from 'react';
import './App.css';
import NavComponent from './navcomponent';
import Login from './login';

import ViewContact from './viewcontact';

import {BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import Home from './home';
import About from './about';
import ViewComp from './ViewComp';
import Gallery from './gallery';


class App extends Component {
  render() {
    return (
      <Router>
      <div className="container" align="textcenter">
      <NavComponent/>
        <Switch>     
          <Route exact path='/contacts' component={ViewContact}/> 
         <Route exact path='/login' component={Login}/>
         <Route exact path='/home' component={Home}/> 
         <Route exact path='/about' component={About}/> 
         <Route exact path='/view' component={ViewComp}/> 
         <Route exact path='/gallery' component={Gallery}/> 
               
        </Switch>

      </div>
      </Router>
    )
  }
}

export default App;
