import React from 'react'
import './App.css';
export class ShowContact extends React.Component {

    render() {
        return (
            <div>
                <h1> Show Contact</h1>
                <table border="1" >
                    <tr>
                        <th>Contact Name</th>
                        <th>Contact Number</th>
                    </tr>
                    <tbody>
                        {this.props.contacts.map((contact) => <tr key={contact}>
                            <td>{contact.contactname} </td>
                            <td>{contact.contactnumber} </td>
                        </tr>
                        )}
                    </tbody>
                </table>
            </div>
        )
    }
}
export default ShowContact;