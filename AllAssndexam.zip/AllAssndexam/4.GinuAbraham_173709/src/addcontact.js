import React from 'react'

export class AddContact extends React.Component {

    contactname = React.createRef();
    contactnumber = React.createRef();
    handleAddContact = () => {
        let contObject = { contactname: this.contactname.current.value, contactnumber: this.contactnumber.current.value }
        this.props.addContact(contObject)
    }
    render() {
        return (
            <div className="well">
                <h1> Add Contacts</h1>
                <form>
                    {/* Add ref to input field */}
                    Contact Name:<input required type="text"  placeholder="Enter Contact Name"
                     ref={this.contactname} />
                    <br /><br />
                    contact Number: <input required type="text"  placeholder="Enter Contact Number"
                      ref={this.contactnumber} />
                    <br /><br />
                    <button onClick={this.handleAddContact} class="btn btn-success">ADD</button>
                </form>
            </div>
        )
    }
}
export default AddContact;