const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    contactname:{type: String},
    contactnumber:{type: Number}
},{
    collection: 'contacts'
})

module.exports= mongoose.model('contacts', ServerPort)

