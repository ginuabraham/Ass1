
function employeeReferalForm(frmEmployeeObj)
{ 
    alert('1');

  if(frmEmployeeObj.checkValidity())
  {  
       alert('2');
       var currentCity = frmEmployeeObj.city.value;
       var state;
    if(currentCity==chennai){
       state= "Tamilnadu";
    }
    else if(currentCity==mumbai || currentCity== pune){
        state= "Maharashtra";
    }
    else{
        state= "Karnataka";
    }
    alert(state);
   }  
}

