function AOperations(operations)
{
    var fnum= parseInt(document.getElementById("txtFN").value);
    var Snum= parseInt(document.getElementById("txtSN").value);
    switch(operations){
        case "+":
        var result=fnum+Snum;
       
        break;
        case "-":
        var result=fnum-Snum;
       
        break;
        case "*":
        var result=fnum*Snum;
       
        break;
        case "/":
        var result=fnum/Snum;
       
        break;

    }
    alert("result is:" +result);

}
