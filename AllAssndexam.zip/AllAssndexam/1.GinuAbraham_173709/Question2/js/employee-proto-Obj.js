//Parent class - Login
class Login
{
    constructor(){}
    //getLogin() function
    getLogin()
    {
        return "getLogin() function called..!"
    }
    // getLogOut() function
    getLogOut()
    {
        return "getLogOut() function called..!"
    }

} // end of Login class

//Derived class - Employee
class Employee extends Login
{
//constructor
constructor(empId, empName, empSalary, empDesignation)
        {
            this._empId_ = empId;
            this._empName_ = empName;
            this._empSalary_ = empSalary;
            this._empDesignation_ = empDesignation;
        }

//overriding
getLogin()
{
    console.log('Login successful');
}
getLogOut()
{
    console.log('Logout Successful');
}

        //function
        printAllDetails()
        {
            let empDetails = 
            `Employee Id : ${this._empId_}
             Employee Name : ${this._empName_}
             Employee Salary : ${this._empSalary_}
             Employee Designation : ${this._empDesignation_}
             `;
             return empDetails;
        }
}//End of Employee class

let LoginObj = new Login();
let empObj01 = new Employee(1002,"Vikash",9812,"Consultant");
//By using proto
//embObj01._proto_ = LOginObj;
//console.log(empObj01._proto_.printAllDetails());

//By Using Object.create()
console.log(empObj01.printAllDetails());
empObj01 = Object.create(LoginObj);
console.log(empObj01.getLogin());

//var empObj02 = new Employee(1003, "Amresh", 6661, "Sr Consultant");


//var empObj03 = new Employee(1001, "Uma", 10000, "Sr Manager");


//var empObj04 = new Employee(1000, "Vaishali", 9123, "Manager");


//creating set object using Set() constructor
let empDetails = new Set();

//CRUD Operations
//Adding to array -->create
empDetails.add(empObj1);
empDetails.add(empObj2);
empDetails.add(empObj3);
empDetails.add(empObj4);

//Reading from an array -->Read
for(var employee of empDetails)
{
    console.log(employee.printAllDetails());
}

//Sorting based on employee ID
console.log("After sorting in ascending order");

let sortedSet = Array.from(empDetails)
.sort((a,b) => a._empId_ - b._empId_);
for(var employee of sortedSet)
   {
     console.log(employee.printAllDetails());
  } 

//removing from a set -> Delete
let empId = prompt("Enter Employee Id");
// using find() method
let deletedEmployee = Array.from(empDetails).find(e => e._empId_ == empId);
if(deletedEmployee == undefined)
{
    console.log("Employee does not exist");
}
else{
    empDetails.delete(deletedEmployee);

    console.log("After removing employee");
    }

//reading from an set ->read
for(var employee of empDetails)
{
    console.log(employee.printAllDetails());
}