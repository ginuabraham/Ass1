
var domainByModule = {
    JEE: ["Core Java", "Servlet-JSP", "Spring"],
    NET: ["C#", "ADO.NET", "ASP.NET"]
}

    function changeDomain(value) {
        if (value.length == 0) document.getElementById("module").innerHTML = "<option></option>";
        else {
            var domOptions = "";
            for (domainId in domainByModule[value]) {
                domOptions += "<option>" + domainByModule[value][domainId] + "</option>";
            }
            document.getElementById("module").innerHTML = domOptions;
        }
    }


function calculateScore(mtp, mtt, assig)
{
    if(mtp.value =="" || mtt.value == "" || assig.value == "")
    {
        alert('Enter All Details ..!');
        return;
    }
    else
    {
        var score = parseInt(mtp.value) + parseInt(mtt.value) + parseInt(assig.value) ;
        document.getElementById("result").innerHTML = "Total Marks : " +score ;
        alert('Total Score : '+score);
    }
}