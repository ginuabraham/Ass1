function register(customer)
{
    //alert('1');
if(customer.checkValidity()){
    localStorage.setItem("cID",customer.txtId.value);
    localStorage.setItem("cFname",customer.txtFName.value);
    localStorage.setItem("cLname",customer.txtLName.value);
    localStorage.setItem("cAddress",customer.ddlAddr.value);
    localStorage.setItem("cAge",customer.txtAge.value);
    localStorage.setItem("cAccountType",customer.rbtnAcc1.value);
    localStorage.setItem("cAccountNum",customer.txtAccNum.value);
    localStorage.setItem("cOpnBal",customer.txtOpBal.value);
    localStorage.setItem("cuser",customer.txtUN.value);
    localStorage.setItem("cpass",customer.txtPD.value);
    //alert('3');
    window.open('login.html');
}
}
function login(frmLoginObj)
    {
    if(frmLoginObj.checkValidity()){
        var username = frmLoginObj.txtUN.value;
        var password = frmLoginObj.txtPD.value;
    var cid= localStorage.getItem("cID");//alert('2');
    var cfname=localStorage.getItem("cFname");
    var csname=localStorage.getItem("cLname");
    var caddress=localStorage.getItem("cAddress");
    var cage=localStorage.getItem("cAge");
    var cat=localStorage.getItem("cAccountType");
    var catn=localStorage.getItem("cAccountNum");
    var cop=localStorage.getItem("cOpnBal");
    var cuser=localStorage.getItem("cuser");
    var cpsw=localStorage.getItem("cpass");
        if(username ==cuser && password ==cpsw)
        {
            var details = `
            Customer ID : ${this.cId}\n
            Customer Name : ${this.cFN} ${this.cLN}\n
            Address : ${this.cAdd}\n
            Age : ${this.cAge}\n
            Account Type : ${this.cAccType}\n
            Opening Balance : ${this.cOpBal}\n`;
           
            var cusObj =  window.open("","DETAILS .. ","width=400px,height=500px");
            var cusDetails = ` <html>
            <head>
                <title>Customer Details</title>
            </head>
            <body >
                <table style="font-family :Monotype Corsiva ;font-size:30px ">
                    <tr align="left">
                        <th>Customer ID </th>
                        <td>${cid}</td>
                    </tr>
                    <tr  align="left">
                        <th>Customer Name</th>
                        <td>${cfname}</td>
                        <td>${csname}</td>
                    </tr>
                    <tr align="left">
                        <th> Address</th>
                        <td>${caddress}</td>
                    </tr>
                    <tr  align="left">
                        <th>Age</th>
                        <td>${cage}</td>
                    </tr>
                    <tr  align="left">
                        <th>Account Type</th>
                        <td>${cat}</td>
                    </tr>
                    <tr  align="left">
                        <th>Opening Balance</th>
                        <td>${cop}</td>
                    </tr>
                </table>
            </body>
        </html>
            
            `
            cusObj.document.write(cusDetails);
            //window.location="register.html"
           
           //alert(window.location);
        }
        else
        alert('Login failed..!');
    }

}