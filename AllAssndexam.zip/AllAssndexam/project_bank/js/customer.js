function dispCandidate() 
{

}